//
//  libraryViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/1/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import WebKit
import Firebase


class libraryViewController: UIViewController {

    @IBAction func open(_ sender: Any) {
        
        let url: URL! = URL(string: "https://firebasestorage.googleapis.com/v0/b/pdfwzrd-7ac8a.appspot.com/o/pdf%2FBCS360-SQL.epub?alt=media&token=7fe0244a-4130-4519-8139-d982db21bef5")
        
        if let url = url {
            let webView = WKWebView(frame: view.frame)
            let urlRequest = URLRequest(url: url)
            webView.load(urlRequest)
            view.addSubview(webView)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
