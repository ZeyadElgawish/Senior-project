//
//  BookStorePDFViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/24/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import WebKit
import FirebaseStorage
import FirebaseDatabase
import FirebaseAuth

class BookStorePDFViewController: UIViewController {
    
    var cName: String = ""
    
    let ref = Database.database().reference()
    let userID : String = (Auth.auth().currentUser?.uid)!
    //gets number of children
    
    @IBOutlet weak var className: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    
    
    @IBAction func addClass(_ sender: Any) {
        
        
        ref.child("users").child(userID).child("Subscription").observeSingleEvent(of: .value, with: {
            (snapshot) in
            
            switch snapshot.value as? String {
            
            case "one":
                self.ref.child("users").child(self.userID).child("Books").observe(.value, with: { (snapshot) in print("snapshot equals: \(snapshot.childrenCount)")
                    let count = Int(snapshot.childrenCount)
                    if count < 1 {
                        self.ref.child("users/\(self.userID)/Books").updateChildValues([ self.cName :"material"])
                        let disableMyButton = sender as? UIButton
                        disableMyButton?.isEnabled = false
                    } else {
                        self.errorLabel.text = "You cannot add more books"
                    }
                })
                
            case "two":
                self.ref.child("users").child(self.userID).child("Books").observe(.value, with: { (snapshot) in print("snapshot equals: \(snapshot.childrenCount)")
                    let count = Int(snapshot.childrenCount)
                    if count < 2 {
                        self.ref.child("users/\(self.userID)/Books").updateChildValues([ self.cName :"material"])
                    } else {
                        self.errorLabel.text = "You cannot add more books"
                    }
                })
                
                
                
            default:
                // ...print an error
                print("Error: Couldn't find type for user")
                //print ("it works")
                //self.adminErrorLabel.text = "You are not authorized to log in here"
            }
        })
        
    }
    
    @IBAction func openPDF(_ sender: Any) {
        let pdfRef = Storage.storage().reference(forURL : "gs://pdfwzrd-7ac8a.appspot.com").child("pdf/\(cName).pdf")
        
        pdfRef.downloadURL(completion: { url , error in
            if error != nil {
                self.errorLabel.text = "Book has been disabled for update"
            } else {
                print("Download URL is \(String(describing: url))")
                let downloadURL = url
                print (downloadURL!)
                
                let url: URL! = downloadURL
                
                
                if let url = url {
                    let webView = WKWebView(frame: self.view.frame)
                    let urlRequest = URLRequest(url: url)
                    webView.load(urlRequest)
                    self.view.addSubview(webView)
                } 
            }
        })
        
        
    }
    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        className.text = cName
        // Do any additional setup after loading the view.

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
