//
//  DeleteBookViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/25/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import Firebase

class DeleteBookViewController: UIViewController {
    
    var ref = Database.database().reference()
   
    var cname: String = ""

    @IBOutlet weak var schoolLabel: UILabel!
    @IBOutlet weak var course: UITextField!
    @IBOutlet weak var courseNum: UITextField!
    
    @IBOutlet weak var courseName: UITextField!
    
    @IBOutlet weak var displayCourse: UILabel!
    
    @IBAction func submitButton(_ sender: Any) {
        if (course.text?.count)! != 3 || course.text == "" || courseNum.text == "" || courseName.text == ""{
            displayCourse.text = "Please fill out form completely"
            
        } else {
            displayCourse.text = "Book: \(course.text!)\(courseNum.text!) - \(courseName.text!) has been deleted from the database. Please send a contact Form with the new book needed for the class"
            cname = "\(course.text!)\(courseNum.text!)-\(courseName.text!)"
        }
        
        
         let pdfRef = Storage.storage().reference(forURL : "gs://pdfwzrd-7ac8a.appspot.com").child("pdf/\(cname).pdf")
        pdfRef.delete { error in
            if error != nil {
                print ("error")
            }
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let userID : String = (Auth.auth().currentUser?.uid)!
        print("Current user ID is" + userID)
        
        self.ref.child("users").child(userID).observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            

            let value = snapshot.value as? NSDictionary
            let school = value?["school"] as? String ?? ""
            self.schoolLabel.text = school
            
            
        })

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
