//
//  MeViewController.swift
//  ProfileTav
//
//  Created by Abraham Hernandez on 4/3/19.
//  Copyright © 2019 Abraham Hernandez. All rights reserved.
//

import UIKit

class MeViewController: UIViewController {

    @IBOutlet weak var classesContainer: UIView!
    @IBOutlet weak var booksContainer: UIView!
    @IBOutlet weak var subscriptionContainer: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var seg: UISegmentedControl!
    
    @IBAction func showComponents(_ sender: UISegmentedControl) {
        
        
        if seg.selectedSegmentIndex == 0
        {
            UIView.animate(withDuration: 0.5) {
                self.classesContainer.alpha = 1
                self.booksContainer.alpha = 0
                self.subscriptionContainer.alpha = 0
            }
        }
        else if seg.selectedSegmentIndex == 1
        {
            UIView.animate(withDuration: 0.5) {
                self.subscriptionContainer.alpha = 1
                self.classesContainer.alpha = 0
                self.booksContainer.alpha = 0
                
                
                
            }
        }
        else
        {
            UIView.animate(withDuration: 0.5) {
                self.booksContainer.alpha = 1
                self.classesContainer.alpha = 0
                self.subscriptionContainer.alpha = 0
                
              
                
            }
        }
    }
}
