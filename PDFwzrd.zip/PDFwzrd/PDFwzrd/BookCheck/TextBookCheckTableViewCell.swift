//
//  TextBookCheckTableViewCell.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/29/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit

class TextBookCheckTableViewCell: UITableViewCell {

    @IBOutlet weak var textBookCheckLabel: UILabel!
    @IBOutlet weak var PDF: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
