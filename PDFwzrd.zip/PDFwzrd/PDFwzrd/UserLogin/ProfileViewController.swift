//
//  ProfileViewController.swift
//  PDFwzrd
//
//  Created by User on 4/18/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage


class ProfileViewController: UIViewController {

    @IBOutlet weak var about: UITextField!
    @IBOutlet weak var handle: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var profilePicture: UIImageView!
    @IBOutlet weak var likesContainer: UIView!
    @IBOutlet weak var mediaContainer: UIView!
    @IBOutlet weak var tweetsContainer: UIView!
    
    //var loggedInUser = AnyObject?()
    //var loggedInUser: User?
    var loggedInUser: User?
    
    let storageRef = Storage.storage().reference()
    let databaseRef = Database.database().reference()

    
    // structure definition goes here
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        self.loggedInUser = Auth.auth().currentUser
        
        self.databaseRef.child("user_profiles").child(self.loggedInUser!.uid).observeSingleEventOfType(.Value) { (snapshot:DataSnapshot) in
            
            self.name.text = snapshot.value!["name"] as? String
            self.handle.text = snapshot.value!["handle"] as? String
            
            //initially the user will not have an about data
            
            if(snapshot.value!["about"] !== nil)
            {
                self.about.text = snapshot.value!["about"] as? String
            }
            
            if(snapshot.value!["profile_pic"] !== nil)
            {
                let databaseProfilePic = snapshot.value!["profile_pic"]
                    as! String
                
                let data = NSData(contentsOfURL: NSURL(string: databaseProfilePic)!)
                
                self.setProfilePicture(self.profilePicture,imageToSet:UIImage(data:data!)!)
            }
            
            //self.imageLoader.stopAnimating()
        }
        // Do any additional setup after loading the view.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func didTapLogout(_ sender: Any) {
        
        try! Auth.auth().signOut()
        
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let welcomeViewController: UIViewController = mainStoryboard.instantiateViewController(withIdentifier: "welcomeViewController")
        
        self.present(welcomeViewController, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func showComponents(_ sender: Any) {
        
        if((sender as AnyObject).selectedSegmentIndex == 0)
        {
            UIView.animate(withDuration: 0.5, animations: {
                
                self.tweetsContainer.alpha = 1
                self.mediaContainer.alpha = 0
                self.likesContainer.alpha = 0
            })
        }
        else if((sender as AnyObject).selectedSegmentIndex == 1)
        {
            UIView.animate(withDuration: 0.5, animations: {
                
                self.mediaContainer.alpha = 1
                self.tweetsContainer.alpha = 0
                self.likesContainer.alpha = 0
                
            })
        }
        else
        {
            UIView.animate(withDuration: 0.5, animations: {
                self.likesContainer.alpha = 1
                self.tweetsContainer.alpha = 0
                self.mediaContainer.alpha = 0
            })
        }
        
        
    }
    internal func setProfilePicture(imageView:UIImageView,imageToSet:UIImage)
    {
        imageView.layer.cornerRadius = 10.0
        imageView.layer.borderColor = UIColor.white.cgColor
        imageView.layer.masksToBounds = true
        imageView.image = imageToSet
    }
}

