//
//  libraryViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/1/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import WebKit
import Firebase


class libraryViewController: UIViewController {

    @IBAction func open(_ sender: Any) {
        
        let url: URL! = URL(string: "https://firebasestorage.googleapis.com/v0/b/pdfwzrd-7ac8a.appspot.com/o/pdf%2FUnlimited%20Memory_%20How%20to%20Use%20Advanced%20Learning%20Strategies%20to%20Learn%20Faster%20(%20PDFDrive.com%20).pdf?alt=media&token=ea6c586f-3bc8-4e8a-8352-d0555e2976d5")
        
        if let url = url {
            let webView = WKWebView(frame: view.frame)
            let urlRequest = URLRequest(url: url)
            webView.load(urlRequest)
            view.addSubview(webView)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
