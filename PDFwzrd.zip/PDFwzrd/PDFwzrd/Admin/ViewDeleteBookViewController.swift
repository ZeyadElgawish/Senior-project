//
//  ViewDeleteBookViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/30/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import Firebase

class ViewDeleteBookViewController: UIViewController {

    var ref = Database.database().reference()
    var bookNameData: String = ""
    @IBOutlet weak var notification: UILabel!
    @IBOutlet weak var schoolLabel: UILabel!
    @IBOutlet weak var bookName: UILabel!
    @IBAction func DeleteBook(_ sender: Any) {
        print(bookNameData)
        notification.text = "Book: \(bookNameData).pdf has been deleted from the database. Please send a contact Form with the new book needed for the class"
        
        self.ref.child("Colleges/\(self.schoolLabel.text!)/\(self.bookNameData)/Textbook").updateChildValues([ "Name" : "  "])
        
        
        let pdfRef = Storage.storage().reference(forURL : "gs://pdfwzrd-7ac8a.appspot.com").child("pdf/\(bookNameData).pdf")
        pdfRef.delete { error in
            if error != nil {
                self.notification.text = "This book is not in the system"
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(bookNameData)
        // Do any additional setup after loading the view.
        bookName.text = bookNameData + ".pdf"
        let userID : String = (Auth.auth().currentUser?.uid)!
        print("Current user ID is" + userID)
        
        self.ref.child("users").child(userID).observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            
            let value = snapshot.value as? NSDictionary
            let school = value?["school"] as? String ?? ""
            self.schoolLabel.text = school
            
            
        })
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
