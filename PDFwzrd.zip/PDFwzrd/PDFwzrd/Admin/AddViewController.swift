//
//  AddViewController.swift
//  PDFwzrd
//
//  Created by Romelo Lopez on 4/11/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth

class AddViewController: UIViewController {
    
    var ref = Database.database().reference()
    var cname: String = ""
    @IBOutlet weak var schoolName: UILabel!
    @IBOutlet weak var course: UITextField!
    @IBOutlet weak var courseNum: UITextField!
    @IBOutlet weak var courseName: UITextField!
    @IBOutlet weak var displayCourse: UILabel!
    
    @IBAction func submitChanges(_ sender: Any) {
        if (course.text?.count)! != 3 || course.text == "" || courseNum.text == "" || courseName.text == ""{
            displayCourse.text = "Please fill out form completely"
            
        } else {
            displayCourse.text = "Course: \(course.text!)\(courseNum.text!) - \(courseName.text!) has been added to the database"
            cname = "\(course.text!)\(courseNum.text!) - \(courseName.text!)"
        }
        
        ref.child("Colleges/\(schoolName.text!)").updateChildValues([ cname :"class"])
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let userID : String = (Auth.auth().currentUser?.uid)!
        print("Current user ID is" + userID)
        
        self.ref.child("users").child(userID).observeSingleEvent(of: .value, with: {(snapshot) in
            print(snapshot.value!)
            
            //let userEmail = (snapshot.value as! NSDictionary)["addedByUser"] as! String
            //print(userEmail)
            let value = snapshot.value as? NSDictionary
            let school = value?["school"] as? String ?? ""
            self.schoolName.text = school
            
            
        })
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

